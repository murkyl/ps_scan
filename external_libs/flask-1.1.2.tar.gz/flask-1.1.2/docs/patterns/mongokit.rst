:orphan:

MongoDB with MongoKit
=====================

MongoKit is no longer maintained. See :doc:`/patterns/mongoengine`
instead.
